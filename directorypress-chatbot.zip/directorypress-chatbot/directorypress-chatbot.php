<?php
/*
Plugin Name: DirectoryPress Chatbot
Description: A chatbot for DirectoryPress that allows users to search for listings (products) and get relevant links, and also answers general questions using ChatGPT.
Version: 1.0
Author: RB Soikot
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

class DirectoryPress_Chatbot {

    private $openai_api_key = '#'; // Replace with your OpenAI API key

    public function __construct() {
        // Register shortcode
        add_shortcode('directorypress_chatbot', array($this, 'render_chatbot'));

        // Handle AJAX requests
        add_action('wp_ajax_directorypress_chatbot_search', array($this, 'handle_search'));
        add_action('wp_ajax_nopriv_directorypress_chatbot_search', array($this, 'handle_search'));

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
    }

    /**
     * Render the chatbot interface.
     */
    public function render_chatbot() {
        ob_start();
        ?>
        <div id="directorypress-chatbot-section" style="width: 100%; max-width: 900px; margin: 20px auto; font-family: Arial, sans-serif;">
            <div id="chatbot-container" style="border: 1px solid #e0e0e0; border-radius: 10px; overflow: hidden; box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1); background: #ffffff;">
                <div id="chatbot-header" style="background: #0073e6; color: #ffffff; padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                    <h3 style="margin: 0; font-size: 18px;">AI Assistant</h3>
                    <button id="chatbot-toggle" style="background: none; border: none; color: #ffffff; font-size: 24px; cursor: pointer;">-</button>
                </div>
                <div id="chatbot-body" style="padding: 15px; background: #f9f9f9;">
                    <div id="chatbot-messages" style="height: 400px; overflow-y: auto; margin-bottom: 15px;"></div>
                    <div id="chatbot-input-area" style="display: flex; gap: 10px;">
                        <input type="text" id="chatbot-input" placeholder="Type your message..." style="flex: 1; padding: 10px; border: 1px solid #e0e0e0; border-radius: 5px; outline: none;">
                        <button id="chatbot-send" style="background: #0073e6; color: #ffffff; border: none; padding: 10px 15px; border-radius: 5px; cursor: pointer;">Send</button>
                    </div>
                </div>
            </div>
        </div>
        <style>
    /* Chatbot Container */
    #directorypress-chatbot-section {
        width: 100%;
        max-width: 600px;
        margin: 20px auto;
        font-family: Arial, sans-serif;
    }

    #chatbot-container {
        border: 1px solid #e0e0e0;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        background: #ffffff;
    }

    #chatbot-header {
        background: #0073e6;
        color: #ffffff;
        padding: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    #chatbot-header h3 {
        margin: 0;
        font-size: 18px;
    }

    #chatbot-toggle {
        background: none;
        border: none;
        color: #ffffff;
        font-size: 24px;
        cursor: pointer;
    }

    #chatbot-body {
        padding: 15px;
        background: #f9f9f9;
    }

    #chatbot-messages {
        height: 300px;
        overflow-y: auto;
        margin-bottom: 15px;
    }

    #chatbot-input-area {
        display: flex;
        gap: 10px;
    }

    #chatbot-input {
        flex: 1;
        padding: 10px;
        border: 1px solid #e0e0e0;
        border-radius: 5px;
        outline: none;
    }

    #chatbot-send {
        background: #0073e6;
        color: #ffffff;
        border: none;
        padding: 10px 15px;
        border-radius: 5px;
        cursor: pointer;
    }

    /* Chatbot Response Styling */
    .chatbot-response {
        background: #ffffff;
        border-radius: 8px;
        padding: 15px;
        margin: 10px 0;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
        font-family: Arial, sans-serif;
        color: #333;
    }

    .chatbot-response h3 {
        margin: 0 0 10px;
        font-size: 18px;
        color: #0073e6;
    }

    .chatbot-response h3 a {
        color: #0073e6;
        text-decoration: none;
    }

    .chatbot-response h3 a:hover {
        text-decoration: underline;
    }

    .product-details-content {
        font-size: 14px;
        line-height: 1.5;
    }

    .product-details-content p {
        margin: 0 0 10px;
    }

    .product-condition,
    .product-color,
    .product-price,
    .product-address {
        font-weight: bold;
        color: #555;
    }

    .product-description {
        margin-top: 10px;
        color: #555;
    }

    .message.user-message {
        background: #0073e6;
        color: #ffffff;
        margin-left: auto;
        max-width: 80%;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    .message.bot-message {
        background: #e0e0e0;
        color: #000000;
        margin-right: auto;
        max-width: 80%;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    /* Responsive Styles */
    @media (max-width: 768px) {
        #directorypress-chatbot-section {
            padding: 0 10px;
        }

        #chatbot-container {
            border-radius: 0;
        }

        #chatbot-header h3 {
            font-size: 16px;
        }

        #chatbot-toggle {
            font-size: 20px;
        }

        #chatbot-messages {
            height: 250px;
        }

        #chatbot-input-area {
            flex-direction: column;
        }

        #chatbot-send {
            width: 100%;
            margin-top: 10px;
        }

        .message.user-message,
        .message.bot-message {
            max-width: 90%;
        }
    }

    @media (max-width: 480px) {
        #chatbot-header h3 {
            font-size: 14px;
        }

        #chatbot-toggle {
            font-size: 18px;
        }

        #chatbot-messages {
            height: 200px;
        }

        .chatbot-response h3 {
            font-size: 16px;
        }

        .product-details-content {
            font-size: 12px;
        }

        .message.user-message,
        .message.bot-message {
            max-width: 95%;
        }
    }
</style>
        <script>
            jQuery(document).ready(function($) {
                // Submit on Enter key
                $('#chatbot-input').on('keypress', function(e) {
                    if (e.which === 13) { // Enter key
                        $('#chatbot-send').click();
                    }
                });

                // Send message
                $('#chatbot-send').on('click', function() {
                    var query = $('#chatbot-input').val();
                    if (query) {
                        // Add user message
                        $('#chatbot-messages').append('<div class="message user-message">' + query + '</div>');
                        $('#chatbot-input').val('');
                        $('#chatbot-messages').scrollTop($('#chatbot-messages')[0].scrollHeight);

                        // Send AJAX request
                        $.ajax({
                            url: '<?php echo admin_url('admin-ajax.php'); ?>',
                            type: 'POST',
                            data: {
                                action: 'directorypress_chatbot_search',
                                query: query
                            },
                            success: function(response) {
                                // Add bot message
                                $('#chatbot-messages').append('<div class="message bot-message">' + response + '</div>');
                                $('#chatbot-messages').scrollTop($('#chatbot-messages')[0].scrollHeight);
                            }
                        });
                    }
                });

                // Toggle chatbot body visibility
                $('#chatbot-toggle').on('click', function() {
                    $('#chatbot-body').slideToggle();
                    $(this).text($(this).text() === '-' ? '+' : '-');
                });
            });
        </script>
        <?php
        return ob_get_clean();
    }

    /**
     * Handle chatbot search queries.
     */
    public function handle_search() {
        $query = sanitize_text_field($_POST['query']);

        // Remove "I need" from the query if it exists
        $query = preg_replace('/^i need /i', '', $query);

        // Check if the query is a greeting
        if ($this->is_greeting($query)) {
            $response = $this->ask_chatgpt($query); // Use ChatGPT to respond to greetings
            echo $this->format_response($response);
            wp_die();
        }

        // Check for predefined questions
        $predefined_response = $this->get_predefined_response($query);
        if ($predefined_response) {
            echo $this->format_response($predefined_response);
            wp_die();
        }

        // Step 1: Search for the entire sentence in listings and categories
        $response = $this->search_listings_by_category($query); // Search for the entire sentence as a category
        if (empty($response)) {
            global $wpdb;
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE post_type = 'dp_listing' AND post_status = 'publish' AND post_title LIKE %s",
                '%' . $wpdb->esc_like($query) . '%'
            ));

            if ($results) {
                // Return the first matching product link
                $result = $results[0]; // Get the first result
                $price = $this->get_product_price($result->ID); // Get the product price
                $response = $this->format_product_details(
                    $result->ID,
                    $result->post_title,
                    $price,
                    $result->post_content,
                    $this->get_product_address($result->ID),
                    $this->get_product_condition($result->ID),
                    $this->get_product_color($result->ID)
                );
            }
        }

        // Step 2: If no match found, search by individual words
        if (empty($response)) {
            $query_words = explode(' ', $query);
            $found_listings = array(); // To avoid duplicate listings

            foreach ($query_words as $word) {
                $word = trim($word);
                if (empty($word)) continue;

                // Search by category
                $category_results = $this->search_listings_by_category($word);
                if ($category_results) {
                    $response .= $category_results;
                }

                // Search by title
                $results = $wpdb->get_results($wpdb->prepare(
                    "SELECT ID, post_title, post_content FROM {$wpdb->posts} WHERE post_type = 'dp_listing' AND post_status = 'publish' AND post_title LIKE %s",
                    '%' . $wpdb->esc_like($word) . '%'
                ));

                if ($results) {
                    foreach ($results as $result) {
                        if (!in_array($result->ID, $found_listings)) {
                            $price = $this->get_product_price($result->ID); // Get the product price
                            $response .= $this->format_product_details(
                                $result->ID,
                                $result->post_title,
                                $price,
                                $result->post_content,
                                $this->get_product_address($result->ID),
                                $this->get_product_condition($result->ID),
                                $this->get_product_color($result->ID)
                            );
                            $found_listings[] = $result->ID;
                        }
                    }
                }
            }
        }

        if (!empty($response)) {
            echo $this->format_response($response);
        } else {
            // If no products found, ask ChatGPT
            $chatgpt_response = $this->ask_chatgpt($query);
            echo $this->format_response($chatgpt_response);
        }
        wp_die();
    }

    /**
     * Format product details with name, link, and professional design.
     */
    private function format_product_details($product_id, $product_title, $price, $description, $address, $condition, $color) {
        $product_link = get_permalink($product_id); // Get the product link
        $response = '<div class="chatbot-product-details">';
        $response .= '<h3><a href="' . esc_url($product_link) . '">' . esc_html($product_title) . '</a></h3>'; // Product name with link
        $response .= '<div class="product-details-content">';
        
        // Add condition and color if available
        if (!empty($condition)) {
            $response .= '<p class="product-condition"><strong>Condition:</strong> ' . esc_html($condition) . '</p>';
        }
        if (!empty($color)) {
            $response .= '<p class="product-color"><strong>Color:</strong> ' . esc_html($color) . '</p>';
        }

        // Add price if available
        if (!empty($price)) {
            $response .= '<p class="product-price"><strong>Price:</strong> ' . wp_kses($price, array(
                'span' => array(
                    'class' => array()
                )
            )) . '</p>';
        }

        // Add description if available
        if (!empty($description)) {
            $response .= '<div class="product-description"><strong>Description:</strong> ' . wp_kses(wpautop($description), array(
                'strong' => array(),
                'em' => array(),
                'p' => array(),
                'br' => array(),
                'span' => array(
                    'class' => array()
                )
            )) . '</div>';
        }

        // Add address if available
        if (!empty($address)) {
            $response .= '<p class="product-address"><strong>Address:</strong> ' . esc_html($address) . '</p>';
        }

        $response .= '</div>'; // Close product-details-content
        $response .= '</div>'; // Close chatbot-product-details

        return $response;
    }

    /**
     * Format the response with professional styling.
     */
    private function format_response($response) {
        return '<div class="chatbot-response">' . wp_kses($response, array(
            'div' => array(
                'class' => array()
            ),
            'h3' => array(),
            'a' => array(
                'href' => array(),
                'class' => array()
            ),
            'p' => array(
                'class' => array()
            ),
            'strong' => array(),
            'em' => array(),
            'br' => array(),
            'span' => array(
                'class' => array()
            )
        )) . '</div>';
    }

    /**
     * Search listings by category.
     */
    private function search_listings_by_category($category_name) {
        global $wpdb;
        $response = '';

        // Get category ID from the query
        $category = get_term_by('name', $category_name, DIRECTORYPRESS_CATEGORIES_TAX);
        if ($category) {
            $category_id = $category->term_id;

            // Get listings in this category
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT p.ID, p.post_title FROM {$wpdb->posts} p
                INNER JOIN {$wpdb->term_relationships} tr ON p.ID = tr.object_id
                WHERE p.post_type = 'dp_listing' AND p.post_status = 'publish' AND tr.term_taxonomy_id = %d",
                $category_id
            ));

            if ($results) {
                // Return the first matching product link and stop searching
                $result = $results[0]; // Get the first result
                $response = '<p>Here is a product in the category <strong>"' . esc_html($category_name) . '"</strong>:</p>';
                $response .= $this->format_product_details(
                    $result->ID,
                    $result->post_title,
                    $this->get_product_price($result->ID),
                    $this->get_product_description($result->ID),
                    $this->get_product_address($result->ID),
                    $this->get_product_condition($result->ID),
                    $this->get_product_color($result->ID)
                );
            }
        }

        return $response;
    }

    /**
     * Check if the query is a greeting.
     */
    private function is_greeting($query) {
        $greetings = array('hi', 'hello', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening');
        $query = strtolower($query);
        return in_array($query, $greetings);
    }

    /**
     * Get predefined response for specific questions.
     */
    private function get_predefined_response($query) {
        $predefined_questions = array(
            'where is my order' => 'You can track your order by logging into your account and visiting the "Orders" section.',
            'how can i track my order' => 'You can track your order by logging into your account and visiting the "Orders" section.',
            'how long will it take to receive my order' => 'Delivery times vary depending on your location and the shipping method chosen. Typically, it takes 3-5 business days.',
            'can i change my shipping address after placing an order' => 'You may be able to change your shipping address if the order has not yet been processed. Please contact customer support immediately.',
            'do you offer international shipping' => 'Yes, we offer international shipping. Additional fees and longer delivery times may apply.',
            'what shipping methods do you offer' => 'We offer standard, expedited, and express shipping methods.',
            'what payment methods do you accept' => 'We accept credit cards, PayPal, and other major payment methods.',
            'my payment failed—what should i do' => 'Please check your payment details and try again. If the issue persists, contact your bank or use a different payment method.',
            'can i get an invoice for my order' => 'Yes, you can download your invoice from the "Orders" section in your account.',
            'why was my payment declined' => 'Payments can be declined for various reasons, including insufficient funds or incorrect payment details. Please check with your bank.',
            'what is your return policy' => 'We offer a 30-day return policy for most items. Please ensure the item is in its original condition.',
            'how do i request a refund' => 'You can request a refund by contacting customer support or visiting the "Returns" section in your account.',
            'how long does it take to process a refund' => 'Refunds are typically processed within 5-7 business days after we receive the returned item.',
            'do i have to pay for return shipping' => 'Return shipping costs may apply unless the return is due to a defect or error on our part.',
            'can i exchange my product for a different one' => 'Yes, you can request an exchange by contacting customer support.',
            'is this product in stock' => 'Please check the product page for current stock availability.',
            'when will this product be back in stock' => 'We recommend checking the product page regularly for updates on restocking.',
            'do you offer bulk discounts' => 'Yes, we offer bulk discounts for large orders. Please contact our sales team for more information.',
            'how do i know which product is best for me' => 'You can use our product comparison tool or contact customer support for personalized recommendations.',
            'i forgot my password—how can i reset it' => 'You can reset your password by clicking on the "Forgot Password" link on the login page.',
            'how do i change my email address' => 'You can update your email address in the "Account Settings" section of your profile.',
            'how do i delete my account' => 'You can request account deletion by contacting customer support.',
            'why can\'t i log in to my account' => 'Please ensure you are using the correct email and password. If issues persist, reset your password or contact support.',
            'how do i apply a coupon code' => 'You can apply a coupon code during checkout by entering it in the designated field.',
            'why isn\'t my discount code working' => 'Please ensure the code is valid and meets the terms and conditions. Contact support if issues persist.',
            'do you have any ongoing promotions or discounts' => 'Check our promotions page or subscribe to our newsletter for the latest deals.',
            'the website isn\'t loading properly—what should i do' => 'Please try refreshing the page or clearing your browser cache. If the issue persists, contact support.',
            'how do i report a bug or issue' => 'You can report bugs or issues by contacting our technical support team.',
            'i am getting an error while checking out—how do i fix it' => 'Please ensure all required fields are filled correctly. If the issue persists, contact support.',
            'is this item still available' => 'Please check the product page for current availability.',
            'what is the condition of the item' => 'The condition of the item is listed on the product page. It can be New, Like New, Used, etc.',
            'are there any defects, stains, or damages' => 'Any known defects or damages are listed on the product page. For further details, contact the seller.',
            'is the price negotiable' => 'The price may be negotiable. Please contact the seller directly to discuss.',
            'can you offer a discount if i buy multiple items' => 'Discounts for multiple items may be available. Please contact the seller for more information.',
            'what’s the lowest price you’re willing to accept' => 'Please contact the seller directly to discuss pricing.',
            'where is the item located' => 'The item location is listed on the product page.',
            'do you offer delivery or is it pickup only' => 'Delivery options are listed on the product page. Some items may be pickup only.',
            'can we meet at a safe location for exchange' => 'Please contact the seller to arrange a safe meeting location.',
            'do you ship, and if so, what are the shipping costs' => 'Shipping options and costs are listed on the product page.',
            'how soon can i pick up the item' => 'Please contact the seller to arrange a pickup time.',
            'does this item come with instructions/manual' => 'If the item comes with instructions or a manual, it will be listed on the product page.',
            'has this item been recalled or is it still compliant with safety standards' => 'Please check the product page or contact the seller for safety and recall information.',
            'what payment methods do you accept' => 'We accept credit cards, PayPal, and other major payment methods.',
            'do you accept returns if the item isn’t as expected' => 'Our return policy is listed on the product page. Please review it for details.',
            'can i inspect the item before buying' => 'Please contact the seller to arrange an inspection.',
            'can i put a deposit to hold the item' => 'Deposit options may be available. Please contact the seller for more information.',
            'why are you selling this item' => 'Please contact the seller directly for their reasons for selling.',
            'have you had any issues using this item' => 'Please contact the seller for any known issues with the item.',
            'is this item from a smoke-free or pet-free home' => 'Please contact the seller for details about the item\'s environment.'
        );

        $query = strtolower($query);
        foreach ($predefined_questions as $question => $answer) {
            if (strpos($query, $question) !== false) {
                return '<p>' . $answer . '</p>';
            }
        }

        return false;
    }

    /**
     * Ask ChatGPT for a response.
     */
    private function ask_chatgpt($query) {
        $url = 'https://api.openai.com/v1/chat/completions';
        $headers = array(
            'Content-Type' => 'application/json',
            'Authorization' => 'Bearer ' . $this->openai_api_key
        );
        $body = array(
            'model' => 'gpt-3.5-turbo',
            'messages' => array(
                array('role' => 'user', 'content' => $query)
            ),
            'max_tokens' => 150
        );

        $args = array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 15
        );

        $response = wp_remote_post($url, $args);

        if (is_wp_error($response)) {
            return '<p>Sorry, I am unable to process your request at the moment.</p>';
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['choices'][0]['message']['content'])) {
            return '<p>' . $data['choices'][0]['message']['content'] . '</p>';
        } else {
            return '<p>Sorry, I could not understand your question.</p>';
        }
    }

    /**
     * Get the price field ID from the database.
     */
    private function get_price_field_id() {
        global $wpdb;
        $price_field_id = '';

        $field_ids = $wpdb->get_results('SELECT id, type, slug FROM ' . $wpdb->prefix . 'directorypress_fields');
        foreach ($field_ids as $field_id) {
            if ($field_id->type == 'price' && ($field_id->slug == 'price' || $field_id->slug == 'Price')) {
                $price_field_id = $field_id->id;
                break;
            }
        }

        return $price_field_id;
    }

    /**
     * Get the product price.
     */
    private function get_product_price($post_id) {
        $price_field_id = $this->get_price_field_id();
        if (!$price_field_id) {
            return false; // No price field found
        }

        // Get the listing object
        $listing = directorypress_get_listing($post_id);
        if (!$listing || !isset($listing->fields[$price_field_id])) {
            return false; // Listing or price field not found
        }

        // Fetch the price field
        $price_field = $listing->fields[$price_field_id];

        // Render the price value
        return $price_field->renderValueOutput($listing);
    }

    /**
     * Get the product address.
     */
    private function get_product_address($post_id) {
        // Replace this with your logic to fetch the product address
        return 'London, 2240'; // Example address
    }

    /**
     * Get the product condition.
     */
    private function get_product_condition($post_id) {
        // Replace this with your logic to fetch the product condition
        return 'Great Condition'; // Example condition
    }

    /**
     * Get the product color.
     */
    private function get_product_color($post_id) {
        // Replace this with your logic to fetch the product color
        return 'Black'; // Example color
    }

    /**
     * Get the product description.
     */
    private function get_product_description($post_id) {
        // Replace this with your logic to fetch the product description
        return 'Great condition baby stroller, perfect for daily use.'; // Example description
    }

    /**
     * Enqueue scripts.
     */
    public function enqueue_scripts() {
        wp_enqueue_script('jquery');
    }
}

// Initialize the plugin
new DirectoryPress_Chatbot();